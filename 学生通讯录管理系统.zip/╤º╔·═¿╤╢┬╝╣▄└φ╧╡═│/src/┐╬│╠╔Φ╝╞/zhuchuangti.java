package 课程设计;


import javax.activation.DataSource;
import javax.naming.spi.DirStateFactory.Result;
import javax.swing.*;

import com.mysql.cj.jdbc.AbandonedConnectionCleanupThread;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class zhuchuangti extends JFrame 
{
	public zhuchuangti() {
	}
	private JTextArea jTextArea1;
	private JLabel jLabel1;
	private JTextField jTextField1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JLabel jLabel6;
	private JScrollPane jScrollPane1;
	private JButton jButton6;
	private JButton jButton5;
	private JButton jButton4;
	private JButton jButton3;
	private JButton jButton1;
	private JButton jButton2;
	private JTextField jTextField6;
	private JTextField jTextField5;
	private JTextField jTextField4;
	private JTextField jTextField3;
	private JTextField jTextField2;

	public static final String url = "jdbc:mysql://localhost:3306/mydb?useSSL=FALSE&serverTimezone=GMT";  
	public static final String name = "com.mysql.cj.jdbc.Driver";  
	public static final String user = "root";  
	public static final String password = "12345";  

	{
		this.setBounds(100,100,771,400);
		this.setTitle("学生通讯录管理系统");
		Container s= getContentPane();
		s.setBounds(-8, -30, 558, 362);
		{
			jScrollPane1 = new JScrollPane();
			s.add(jScrollPane1);
			jScrollPane1.setBounds(12, 12,720, 120);
			{
				jTextArea1 = new JTextArea();
				jScrollPane1.setViewportView(jTextArea1);
				jTextArea1.setBounds(12, 12, 460, 120);
			}
		}
		{
			jLabel1 = new JLabel();
			s.add(jLabel1);
			jLabel1.setText("\u5b66   \u53f7\uff1a");
			jLabel1.setBounds(12, 146, 48, 18);
		}
		{
			jTextField1 = new JTextField();
			s.add(jTextField1);
			jTextField1.setBounds(60, 144, 78, 24);
		}
		{
			jTextField2 = new JTextField();
			s.add(jTextField2);
			jTextField2.setBounds(226, 144, 78, 24);
		}
		{
			jLabel2 = new JLabel();
			s.add(jLabel2);
			jLabel2.setText("\u59d3\u540d\uff1a");
			jLabel2.setBounds(187, 146, 39, 18);
		}
		{
			jTextField3 = new JTextField();
			s.add(jTextField3);
			jTextField3.setBounds(394, 144, 78, 24);
		}
		{
			jLabel3 = new JLabel();
			s.add(jLabel3);
			jLabel3.setText("\u6027\u522b\uff1a");
			jLabel3.setBounds(355, 145, 39, 18);
		}
		{
			jLabel4 = new JLabel();
			s.add(jLabel4);
			jLabel4.setText("班级：");
			jLabel4.setBounds(12, 180, 54, 17);
		}
		{
			jTextField4 = new JTextField();
			s.add(jTextField4);
			jTextField4.setBounds(60, 180, 78, 24);
		}
		{
			jLabel5 = new JLabel();
			s.add(jLabel5);
			jLabel5.setText("电话：");
			jLabel5.setBounds(185, 180, 43, 17);
		}
		{
			jTextField5 = new JTextField();
			s.add(jTextField5);
			jTextField5.setBounds(226, 180, 78, 24);
		}
		{
			jLabel6 = new JLabel();
			s.add(jLabel6);
			jLabel6.setText("邮箱：");
			jLabel6.setBounds(355, 180, 43, 17);
		}
		{
			jTextField6 = new JTextField();
			s.add(jTextField6);
			jTextField6.setBounds(394, 180, 78, 24);
		}
		{
			jButton1 = new JButton();
			s.add(jButton1);
			jButton1.setText("显示学生信息");
			jButton1.setBounds(12, 221, 135, 24);
			jButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton1.actionPerformed, event="+evt);
					//TODO add your code for jButton1.actionPerformed
					try {
						Class.forName(name);
						System.out.println("驱动加载成功");
					} catch (ClassNotFoundException e) {
						// TODO: handle exception
						System.out.println("SQLException:"+e.getMessage());
					}
					try {
						Connection con=DriverManager.getConnection(url,user,password);
						Statement stmt=con.createStatement();
						ResultSet rs=stmt.executeQuery("select * from employee");
						jTextArea1.setText(null);
						while(rs.next()){
							jTextArea1.append("学号："+rs.getString("no")+"\t");
							jTextArea1.append("姓名："+rs.getString("name")+"\t");
							jTextArea1.append("性别："+rs.getString("sex")+"\t");
							jTextArea1.append("班级："+rs.getString("class")+"\t");
							jTextArea1.append("电话："+rs.getString("phone")+"\t");
							jTextArea1.append("邮箱："+rs.getString("mail")+"\n");
							
								}
						con.close();
						rs.close();
						stmt.close();
					} catch (Exception e) {
						
						// TODO: handle exception
					}
				}
			});
		}
		{
			jButton2 = new JButton();
			s.add(jButton2);
			jButton2.setText("查询学生信息");
			jButton2.setBounds(168, 221, 131, 24);
			jButton2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton2.actionPerformed, event="+evt);
					//TODO add your code for jButton2.actionPerformed
					try {
						
						Class.forName(name);
						System.out.println("驱动加载成功");
					} catch (ClassNotFoundException e) {
						// TODO: handle exception
						System.out.println("SQLException:"+e.getMessage());
					}
					try {
						Connection con=DriverManager.getConnection(url,user,password);
						Statement stmt=con.createStatement();
						String sqlstr="select * from employee where no='"+jTextField1.getText()+"'";
						ResultSet rs=stmt.executeQuery(sqlstr);
						while(rs.next()){
							jTextArea1.setText(null);
							jTextArea1.append("学号："+rs.getString("no")+"\t");
							jTextArea1.append("姓名："+rs.getString("name")+"\t");
							jTextArea1.append("性别："+rs.getString("sex")+"\t");
							jTextArea1.append("班级："+rs.getString("class")+"\t");
							jTextArea1.append("电话："+rs.getString("phone")+"\t");
							jTextArea1.append("邮箱："+rs.getString("mail")+"\n");
						}
						stmt.executeUpdate(sqlstr);
						con.close();
						rs.close();
						stmt.close();
					} catch (Exception e) {
						jTextField1.setText("");
						jTextField2.setText("");
						jTextField3.setText("");
						jTextField4.setText("");
						jTextField5.setText("");
						jTextField6.setText("");
						// TODO: handle exception
					}
				}
			});
		}
		{
			jButton3 = new JButton();
			s.add(jButton3);
			jButton3.setText("插入学生信息");
			jButton3.setBounds(321, 221, 140, 24);
			jButton3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton3.actionPerformed, event="+evt);
					//TODO add your code for jButton3.actionPerformed
					
					try {
						Class.forName(name);
						System.out.println("驱动加载成功");
					} catch (ClassNotFoundException e) {
						// TODO: handle exception
						System.out.println("SQLException:"+e.getMessage());
					}
					try {
						Connection con=DriverManager.getConnection(url,user,password);
						Statement stmt=con.createStatement();
						String sqlstr="insert into employee values('"+jTextField1.getText()+"','"+jTextField2.getText()+"','"+jTextField3.getText()+"','"+jTextField4.getText()+"','"+jTextField5.getText()+"','"+jTextField6.getText()+"')";
						stmt.executeUpdate(sqlstr);
						con.close();
						stmt.close();
						jTextField1.setText("");
						jTextField2.setText("");
						jTextField3.setText("");
						jTextField4.setText("");
						jTextField5.setText("");
						jTextField6.setText("");
					} catch (Exception e) {
						
						
						// TODO: handle exception
					}
				}
			});
		}
		{
			jButton4 = new JButton();
			s.add(jButton4);
			jButton4.setText("修改学生信息");
			jButton4.setBounds(12, 260, 135, 24);
			jButton4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton4.actionPerformed, event="+evt);
					//TODO add your code for jButton4.actionPerformed
					try {
						Class.forName(name);
						System.out.println("驱动加载成功");
					} catch (ClassNotFoundException e) {
						// TODO: handle exception
						System.out.println("SQLException:"+e.getMessage());
					}
					try {
						Connection con=DriverManager.getConnection(url,user,password);
						Statement stmt=con.createStatement();
						String sqlstr="update employee set " +
								"name='"+jTextField2.getText()+"'" +
								",sex='"+jTextField3.getText()+"'" +
								",class='"+jTextField4.getText()+"'" +
								",phone='"+jTextField5.getText()+"'" +
								",mail='"+jTextField6.getText()+"'" +
								"where no='"+jTextField1.getText()+"'";
						stmt.executeUpdate(sqlstr);
						con.close();
						stmt.close();
						jTextField1.setText("");
						jTextField2.setText("");
						jTextField3.setText("");
						jTextField4.setText("");
						jTextField5.setText("");
						jTextField6.setText("");
					} catch (Exception e) {
						
						// TODO: handle exception
					}
				}
			});
		}
		{
			jButton5 = new JButton();
			s.add(jButton5);
			jButton5.setText("删除学生信息");
			jButton5.setBounds(167, 260, 132, 24);
			jButton5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton5.actionPerformed, event="+evt);
					//TODO add your code for jButton5.actionPerformed
					try {
						Class.forName(name);
						System.out.println("驱动加载成功");
					} catch (ClassNotFoundException e) {
						// TODO: handle exception
						System.out.println("SQLException:"+e.getMessage());
					}
					try {
						Connection con=DriverManager.getConnection(url,user,password);
						Statement stmt=con.createStatement();
						String sqlstr="delete from employee where no='"+jTextField1.getText()+"'";
						stmt.executeUpdate(sqlstr);
						con.close();
						stmt.close();
						jTextField1.setText("");
						jTextField2.setText("");
						jTextField3.setText("");
						jTextField4.setText("");
						jTextField5.setText("");
						jTextField6.setText("");
					} catch (Exception e) {
						
						// TODO: handle exception
					}
				}
			});
		}
		{
			jButton6 = new JButton();
			s.add(jButton6);
			jButton6.setText("\u9000\u51fa");
			jButton6.setBounds(321, 260, 140, 24);
			jButton6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					System.out.println("jButton6.actionPerformed, event="+evt);
					//TODO add your code for jButton6.actionPerformed
					System.exit(0);
				}
			});
		}
		{	
		getContentPane().setLayout(null);
		this.setAlwaysOnTop(false);
		
		}
	}
}

